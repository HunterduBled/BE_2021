package robotBlue2;

import lejos.nxt.remote.AsciizCodec;
import lejos.nxt.remote.NXTCommand;
import lejos.nxt.remote.NXTProtocol;
import lejos.nxt.remote.RemoteMotor;
import lejos.pc.comm.NXTComm;
import lejos.pc.comm.NXTCommException;
import lejos.pc.comm.NXTCommFactory;
import lejos.pc.comm.NXTInfo;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.IOException;
import java.io.UnsupportedEncodingException;

import graphe.FormeCase;
import graphe.Node;


public class Robot{
	NXTComm nxtComm=null;
	NXTInfo[] nxtInfo=null;
	public RemoteMotor MD=null;
	public RemoteMotor MG=null;
	boolean allumerD=true;
	boolean allumerG=true;
	NXTCommand nxtCommand;
	String nameRobot;
	int orientation;
	int nbVictimes;
	int tailleCamion;
	
	static byte[] avancer;
    static byte[] demitour;
    static byte[] slipgauche;
    static byte[] slipdroit;
    static byte[] wait;
	
	public Robot(String nameRobot,int orientation,int tailleCamion) {
		this.nameRobot=nameRobot;
		this.orientation=orientation;
		this.tailleCamion=tailleCamion;
	}
	public NXTComm getNxtComm() {
		return nxtComm;
	}
	public void setNxtComm(NXTComm nxtComm) {
		this.nxtComm = nxtComm;
	}
	public NXTInfo[] getNxtInfo() {
		return nxtInfo;
	}
	public NXTInfo getNxtInfoCase(int E){
		return nxtInfo[E];
	}
	public RemoteMotor getMD() {
		return MD;
	}
	public void setMD(RemoteMotor mD) {
		MD = mD;
	}
	public RemoteMotor getMG() {
		return MG;
	}
	public void setMG(RemoteMotor mG) {
		MG = mG;
	}
	public String getRobotName(){
		return this.nameRobot;
	}
	public NXTCommand getNXTCommand(){
		return this.nxtCommand;
	}
	
	public int getOrientation() {
		return orientation;
	}
	public void setOrientation(int orientation) {
		this.orientation = orientation;
	}
	public int getNbVictimes() {
		return nbVictimes;
	}
	public void setNbVictimes(int nbVictimes) {
		this.nbVictimes = nbVictimes;
	}
	public int getTailleCamion() {
		return tailleCamion;
	}
	public static void init() throws UnsupportedEncodingException{
    	avancer = new byte[22];
    	avancer[0]=(byte)0x00;
    	avancer[1]=(byte)0x00;
        System.arraycopy(AsciizCodec.encode("av.rxe"), 0, avancer, 2, AsciizCodec.encode("av.rxe").length);
        
        demitour = new byte[22];
        demitour[0]=(byte)0x00;
        demitour[1]=(byte)0x00;
        System.arraycopy(AsciizCodec.encode("dt.rxe"), 0, demitour, 2, AsciizCodec.encode("dt.rxe").length);
        
        slipgauche = new byte[22];
        slipgauche[0]=(byte)0x00;
        slipgauche[1]=(byte)0x00;
        System.arraycopy(AsciizCodec.encode("sg.rxe"), 0, slipgauche, 2, AsciizCodec.encode("sg.rxe").length);
        
        slipdroit = new byte[22];
        slipdroit[0]=(byte)0x00;
        slipdroit[1]=(byte)0x00;
        System.arraycopy(AsciizCodec.encode("sd.rxe"), 0, slipdroit, 2, AsciizCodec.encode("sd.rxe").length);
        
        wait = new byte[2];
        wait[0]=(byte)0x00;
        wait[1]=(byte)0x11;
        
    }
	
	public void connexion() throws NXTCommException, InterruptedException, UnsupportedEncodingException{
		this.nxtComm = NXTCommFactory.createNXTComm(NXTCommFactory.BLUETOOTH);
		this.nxtInfo = nxtComm.search(this.nameRobot);
	    if (this.nxtInfo.length == 0) {
	        System.out.println("No nxt found");
	        System.exit(1);
	    }
	    this.nxtComm.open(this.nxtInfo[0]);
	    System.out.println("Connect� � "+ this.nxtInfo[0].name+" avec addresse " +this.nxtInfo[0].deviceAddress);
	    nxtCommand = new NXTCommand(nxtComm);
	    init();
	}
	public void initMotor(int emplacementMD,int emplacementMG){
		this.MD = new RemoteMotor(new NXTCommand(this.nxtComm), emplacementMD);
	    this.MG = new RemoteMotor(new NXTCommand(this.nxtComm), emplacementMG);
	    MD.setSpeed(400);
	    MG.setSpeed(400);
	}
	public void initLight() throws IOException{
		nxtCommand.setInputMode(3,NXTProtocol.LIGHT_ACTIVE,NXTProtocol.RAWMODE);
	    nxtCommand.setInputMode(0,NXTProtocol.LIGHT_ACTIVE,NXTProtocol.RAWMODE);
	}
	
	public void modifMotorD(int speed){
		MD.setSpeed(speed);
	}
	public void modifMotorG(int speed){
		MG.setSpeed(speed);
	}
	
	public boolean demiTour(Node n0, Node n1) throws IOException{
		if (n0.getCoorX()>n1.getCoorX() && this.orientation==3){
			System.out.println("- On part de la case "+n0.getName()+" vers la case "+n1.getName());
			System.out.println("Faire demi-tour");
			//nxtComm.sendRequest(demitour,3);
			this.orientation=(this.orientation+6)%12;
			return true;
		}
		else if (n0.getCoorX()<n1.getCoorX() && this.orientation==9 ){
			System.out.println("- On part de la case "+n0.getName()+" vers la case "+n1.getName());
			System.out.println("Faire demi-tour");
			//nxtComm.sendRequest(demitour,3);
			this.orientation=(this.orientation+6)%12;
			return true;
		}
		else if (n0.getCoorY()>n1.getCoorY() && this.orientation==0 ){
			System.out.println("- On part de la case "+n0.getName()+" vers la case "+n1.getName());
			System.out.println("Faire demi-tour");
			//nxtComm.sendRequest(demitour,3);
			this.orientation=(this.orientation+6)%12;
			return true;
		}
		else if (n0.getCoorY()<n1.getCoorY() && this.orientation==6){
			System.out.println("- On part de la case "+n0.getName()+" vers la case "+n1.getName());
			System.out.println("Faire demi-tour");
			//nxtComm.sendRequest(demitour,3);
			this.orientation=(this.orientation+6)%12;
			return true;
		}
		else{
			return false;
		}
	}

	public void orientation(Node n0, Node n1) throws IOException{
		if (n0.getCoorX()-n1.getCoorX()==0 && n0.getCoorY()-n1.getCoorY()==-1 && this.orientation==0){
			//nxtComm.sendRequest(avancer,3);
			System.out.println("Avancer");
		}
		else if (n0.getCoorX()-n1.getCoorX()==1 && n0.getCoorY()-n1.getCoorY()==0 && this.orientation==0){
			this.orientation=9;
			//nxtComm.sendRequest(avancer,3);
			System.out.println("Gauche");
		}
		else if (n0.getCoorX()-n1.getCoorX()==-1 && n0.getCoorY()-n1.getCoorY()==0 && this.orientation==0){
			this.orientation=(this.orientation+3)%12;
			//nxtComm.sendRequest(avancer,3);
			System.out.println("Droite");
		}
		else if (n0.getCoorX()-n1.getCoorX()==0 && n0.getCoorY()-n1.getCoorY()==-1 && this.orientation==3){
			this.orientation=(this.orientation-3)%12;
			//nxtComm.sendRequest(avancer,3);
			System.out.println("Gauche");
		}
		else if (n0.getCoorX()-n1.getCoorX()==-1 && n0.getCoorY()-n1.getCoorY()==0 && this.orientation==3){
			//nxtComm.sendRequest(avancer,3);
			System.out.println("Avancer");
		}
		else if (n0.getCoorX()-n1.getCoorX()==0 && n0.getCoorY()-n1.getCoorY()==1 && this.orientation==3){
			this.orientation=(this.orientation+3)%12;
			//nxtComm.sendRequest(avancer,3);
			System.out.println("Droite");
		}
		else if (n0.getCoorX()-n1.getCoorX()==0 && n0.getCoorY()-n1.getCoorY()==1 && this.orientation==6){
			//nxtComm.sendRequest(avancer,3);
			System.out.println("Avancer");
		}
		else if (n0.getCoorX()-n1.getCoorX()==1 && n0.getCoorY()-n1.getCoorY()==0 && this.orientation==6){
			this.orientation=(this.orientation+3)%12;
			//nxtComm.sendRequest(avancer,3);
			System.out.println("Droite");
		}
		else if (n0.getCoorX()-n1.getCoorX()==-1 && n0.getCoorY()-n1.getCoorY()==0 && this.orientation==6){
			this.orientation=(this.orientation-3)%12;
			//nxtComm.sendRequest(avancer,3);
			System.out.println("Gauche");
		}
		else if (n0.getCoorX()-n1.getCoorX()==0 && n0.getCoorY()-n1.getCoorY()==-1 && this.orientation==9){
			this.orientation=(this.orientation+3)%12;
			//nxtComm.sendRequest(avancer,3);
			System.out.println("Droite");
		}
		else if (n0.getCoorX()-n1.getCoorX()==1 && n0.getCoorY()-n1.getCoorY()==0 && this.orientation==9){
			//nxtComm.sendRequest(avancer,3);
			System.out.println("Avancer");
		}
		else if (n0.getCoorX()-n1.getCoorX()==0 && n0.getCoorY()-n1.getCoorY()==1 && this.orientation==9){
			this.orientation=(this.orientation-3)%12;
			//nxtComm.sendRequest(avancer,3);
			System.out.println("Gauche");
		}
	}
	
	public void orientationSlip(Node n0, Node n1) throws IOException{
		if (n0.getCoorX()-n1.getCoorX()==0 && n0.getCoorY()-n1.getCoorY()==-1 && this.orientation==0){
			if (n0.getfCases()==FormeCase.SG){
				//nxtComm.sendRequest(slipdroit,3);
				System.out.println("Avancer SlipD");
			}
			else{
				//nxtComm.sendRequest(slipgauche,3);
				System.out.println("Avancer SlipG");
			}
			System.out.println("1");
		}
		else if (n0.getCoorX()-n1.getCoorX()==1 && n0.getCoorY()-n1.getCoorY()==0 && this.orientation==0){
			this.orientation=9;
			//nxtComm.sendRequest(slipgauche,3);
			System.out.println("Gauche Slip");
		}
		else if (n0.getCoorX()-n1.getCoorX()==-1 && n0.getCoorY()-n1.getCoorY()==0 && this.orientation==0){
			this.orientation=(this.orientation+3)%12;
			//nxtComm.sendRequest(slipdroit,3);
			System.out.println("Droite Slip");
		}
		else if (n0.getCoorX()-n1.getCoorX()==0 && n0.getCoorY()-n1.getCoorY()==-1 && this.orientation==3){
			this.orientation=(this.orientation-3)%12;
			//nxtComm.sendRequest(slipgauche,3);
			System.out.println("Gauche Slip");
		}
		else if (n0.getCoorX()-n1.getCoorX()==-1 && n0.getCoorY()-n1.getCoorY()==0 && this.orientation==3){
			if (n0.getfCases()==FormeCase.SH){
				//nxtComm.sendRequest(slipdroit,3);
				System.out.println("Avancer SlipD");
			}
			else {
				//nxtComm.sendRequest(slipgauche,3);
				System.out.println("Avancer SlipG");
			}
			System.out.println("2");
		}
		else if (n0.getCoorX()-n1.getCoorX()==0 && n0.getCoorY()-n1.getCoorY()==1 && this.orientation==3){
			this.orientation=(this.orientation+3)%12;
			//nxtComm.sendRequest(slipdroit,3);
			System.out.println("Droite Slip");
		}
		else if (n0.getCoorX()-n1.getCoorX()==0 && n0.getCoorY()-n1.getCoorY()==1 && this.orientation==6){
			if (n0.getfCases()==FormeCase.SG){
				//nxtComm.sendRequest(slipgauche,3);
				System.out.println("Avancer SlipG");
			}
			else{
				//nxtComm.sendRequest(slipdroit,3);
				System.out.println("Avancer SlipD");
			}
			System.out.println("3");
		}
		else if (n0.getCoorX()-n1.getCoorX()==1 && n0.getCoorY()-n1.getCoorY()==0 && this.orientation==6){
			this.orientation=(this.orientation+3)%12;
			//nxtComm.sendRequest(slipdroit,3);
			System.out.println("Droite Slip");
		}
		else if (n0.getCoorX()-n1.getCoorX()==-1 && n0.getCoorY()-n1.getCoorY()==0 && this.orientation==6){
			this.orientation=(this.orientation-3)%12;
			//nxtComm.sendRequest(slipgauche,3);
			System.out.println("Gauche Slip");
		}
		else if (n0.getCoorX()-n1.getCoorX()==0 && n0.getCoorY()-n1.getCoorY()==-1 && this.orientation==9){
			this.orientation=(this.orientation+3)%12;
			//nxtComm.sendRequest(slipdroit,3);
			System.out.println("Droite Slip");
		}
		else if (n0.getCoorX()-n1.getCoorX()==1 && n0.getCoorY()-n1.getCoorY()==0 && this.orientation==9){
			if (n0.getfCases()==FormeCase.SH){
				//nxtComm.sendRequest(slipgauche,3);
				System.out.println("Avancer SlipG");
			}
			else {
				//nxtComm.sendRequest(slipdroit,3);
				System.out.println("Avancer SlipD");
			}
			System.out.println("4");
		}
		else if (n0.getCoorX()-n1.getCoorX()==0 && n0.getCoorY()-n1.getCoorY()==1 && this.orientation==9){
			this.orientation=(this.orientation-3)%12;
			//nxtComm.sendRequest(slipgauche,3);
			System.out.println("Gauche Slip");
		}
	}
}
	