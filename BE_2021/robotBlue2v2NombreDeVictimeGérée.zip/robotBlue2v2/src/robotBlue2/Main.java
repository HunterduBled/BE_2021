package robotBlue2;

import java.io.IOException;
import java.util.LinkedList;
import java.util.concurrent.TimeUnit;

import lejos.pc.comm.NXTCommException;
import lejos.robotics.navigation.DifferentialPilot;
import graphe.*;


public class Main {

	/**
	 * @param args
	 * @throws IOException 
	 * @throws InterruptedException 
	 */
	public static void deplacerRobot(Graph graph,Robot robot,Node n) throws IOException, InterruptedException{
		LinkedList<Node> shortestPathTemp = (LinkedList<Node>) n.getShortestPath();
		shortestPathTemp.addLast(n);
		System.out.println("--- Parcours de "+shortestPathTemp.get(0).getName()+" vers "+n.getName()+" ---");
		
		if (robot.demiTour(shortestPathTemp.get(0), shortestPathTemp.get(1))){
			shortestPathTemp.removeFirst();
			//TimeUnit.SECONDS.sleep(7);
		}
		
		while (shortestPathTemp.size()>1){
			System.out.println("- On part de la case "+shortestPathTemp.get(0).getName()+" vers la case "+shortestPathTemp.get(1).getName());
			//System.out.println(shortestPathTemp.get(0).getName());
			if (shortestPathTemp.get(0).getfCases()==FormeCase.SB ||shortestPathTemp.get(0).getfCases()==FormeCase.SH ||shortestPathTemp.get(0).getfCases()==FormeCase.SG ||shortestPathTemp.get(0).getfCases()==FormeCase.SD){
				robot.orientationSlip(shortestPathTemp.get(0), shortestPathTemp.get(1));
			}
			else{
				robot.orientation(shortestPathTemp.get(0), shortestPathTemp.get(1));
			}
			//TimeUnit.SECONDS.sleep(7);
			shortestPathTemp.removeFirst();			
		}
	}
	
	public static void SelectionDirection(Graph graph,Robot robot,TypeCase cases ) throws IOException, InterruptedException{
		int cheminPlusCourt=Integer.MAX_VALUE;;
		//LinkedList<Node> shortestPathTemp;
		Node nodeTemp = null;
		if (cases==TypeCase.VICTIME){
			for(Node n : graph.getNodes()){
				if(n.gettCases() == cases && n.getShortestPath().size()<cheminPlusCourt){
					nodeTemp=n;
					cheminPlusCourt= n.getShortestPath().size();
				}
			}
			deplacerRobot(graph, robot, nodeTemp);
			System.out.println("La victime a bien �t� r�cup�r�e sur la case "+nodeTemp.getName());
			nodeTemp.settCases(TypeCase.RIEN);
			robot.setNbVictimes(robot.getNbVictimes()+1);
		}
		else if (cases==TypeCase.HOPITAL){
			for(Node n : graph.getNodes()){
				if(n.gettCases() == cases){
					nodeTemp=n;
				}
			}
		deplacerRobot(graph, robot, nodeTemp);
		System.out.println("La ou les  victime(s) a(ont) bien �t� amen�(s) � l'hopital "+nodeTemp.getName());
		}
		graph.reset(graph);
		graph.calculateShortestPathFromSource(graph,nodeTemp);
	}
	
	public static boolean Victime(Graph graph){
		boolean victimeASoigner=false;
		for(Node n : graph.getNodes()){
			if(n.gettCases() == TypeCase.VICTIME){
				victimeASoigner=true;
			}
		}
		return victimeASoigner;
	}
	
	
	public static void main(String[] args) throws IOException, NXTCommException, InterruptedException {
		// TODO Auto-generated method stub
		final Robot robot= new Robot("Say my n",6,2);
		//robot.connexion();
		//robot.initMotor(0,1);
		//robot.initLight();
//		final DifferentialPilot pilote = new DifferentialPilot(4.96f,13.0f,robot.getMG(),robot.getMD(),false);
		
		Node nodeH = new Node("nodeH",FormeCase.V,TypeCase.RIEN,0,1);
		Node nodeD = new Node("nodeD",FormeCase.L,TypeCase.RIEN,0,2);
		Node nodeA = new Node("nodeA",FormeCase.V,TypeCase.VICTIME,0,3);
		Node nodeL = new Node("nodeL",FormeCase.V,TypeCase.RIEN,1,0);
		Node nodeI = new Node("nodeI",FormeCase.SG,TypeCase.RIEN,1,1);
		Node nodeE = new Node("nodeE",FormeCase.L,TypeCase.RIEN,1,2);
		Node nodeB = new Node("nodeB",FormeCase.SB,TypeCase.RIEN,1,3);
		Node nodeM = new Node("nodeM",FormeCase.SH,TypeCase.RIEN,2,0);
		Node nodeJ = new Node("nodeJ",FormeCase.L,TypeCase.HOPITAL,2,1);
		Node nodeF = new Node("nodeF",FormeCase.V,TypeCase.RIEN,2,2);
		Node nodeC = new Node("nodeC",FormeCase.SB,TypeCase.RIEN,2,3);
		Node nodeN = new Node("nodeN",FormeCase.V,TypeCase.VICTIME,3,0);
		Node nodeK = new Node("nodeK",FormeCase.L,TypeCase.RIEN,3,1);
		Node nodeG = new Node("nodeG",FormeCase.SG,TypeCase.RIEN,3,2);
		Node nodeO = new Node("nodeO",FormeCase.V,TypeCase.VICTIME,3,3);
		
		nodeH.addDestination(nodeD, 1);
		nodeH.addDestination(nodeI, 1);
		nodeD.addDestination(nodeH, 1);
		nodeD.addDestination(nodeA, 1);
		nodeA.addDestination(nodeD, 1);
		nodeA.addDestination(nodeB, 1);
		nodeL.addDestination(nodeI, 1);
		nodeL.addDestination(nodeM, 1);
		nodeI.addDestination(nodeL, 1);
		nodeI.addDestination(nodeH, 1);
		nodeI.addDestination(nodeE, 1);
		nodeE.addDestination(nodeI, 1);
		nodeE.addDestination(nodeB, 1);
		nodeB.addDestination(nodeE, 1);
		nodeB.addDestination(nodeA, 1);
		nodeB.addDestination(nodeC, 1);
		nodeM.addDestination(nodeL, 1);
		nodeM.addDestination(nodeN, 1);
		nodeM.addDestination(nodeJ, 1);
		nodeJ.addDestination(nodeM, 1);
		nodeF.addDestination(nodeC, 1);
		nodeF.addDestination(nodeG, 1);
		nodeC.addDestination(nodeF, 1);
		nodeC.addDestination(nodeB, 1);
		nodeC.addDestination(nodeO, 1);
		nodeN.addDestination(nodeM, 1);
		nodeN.addDestination(nodeK, 1);
		nodeK.addDestination(nodeN, 1);
		nodeK.addDestination(nodeG, 1);
		nodeG.addDestination(nodeK, 1);
		nodeG.addDestination(nodeF, 1);
		nodeG.addDestination(nodeO, 1);
		nodeO.addDestination(nodeC, 1);
		nodeO.addDestination(nodeG, 1);
			
		Graph graph = new Graph();
		
		graph.addNode(nodeA);
		graph.addNode(nodeB);
		graph.addNode(nodeC);
		graph.addNode(nodeD);
		graph.addNode(nodeE);
		graph.addNode(nodeF);
		graph.addNode(nodeG);
		graph.addNode(nodeH);
		graph.addNode(nodeI);
		graph.addNode(nodeJ);
		graph.addNode(nodeK);
		graph.addNode(nodeL);
		graph.addNode(nodeM);
		graph.addNode(nodeN);
		graph.addNode(nodeO);					
		
		Node nodeDepart = nodeJ;
		graph.calculateShortestPathFromSource(graph,nodeDepart);
		
		while (Victime(graph)){
			while(robot.getNbVictimes()<robot.getTailleCamion() && Victime(graph)){
				SelectionDirection(graph,robot,TypeCase.VICTIME);
			}
			if (robot.getNbVictimes()==robot.getTailleCamion()){
				System.out.println("Le camion est plein , il doit aller d�poser les victimes");
			}
			robot.setNbVictimes(0);
			SelectionDirection(graph,robot,TypeCase.HOPITAL);
		}
		
		
		System.out.println("\" Say my n \" a fini son service, la Capsule Corp n'est en rien responsable des dommages occasionn�s durant le transport");

	}
}
