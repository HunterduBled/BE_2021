package graphe;

public enum TypeCase {
	HOPITAL,VICTIME,RIEN;
}
