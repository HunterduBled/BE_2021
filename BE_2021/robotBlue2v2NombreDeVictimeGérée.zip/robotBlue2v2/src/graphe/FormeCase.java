package graphe;

public enum FormeCase {
	L,V,SH,SB,SD,SG;
}
